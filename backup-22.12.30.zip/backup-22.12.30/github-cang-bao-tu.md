---
description: 发布于2022.10.28
---

# GitHub 藏宝图

- chinawareblock - 流氓软件终结者 https://github.com/sharoue/chinawareblock
- CloudflareSpeedTest - 「自选优选 IP」测试 Cloudflare CDN 延迟和速度 https://github.com/XIU2/CloudflareSpeedTest
- BilibiliLiveRecorder - 直播视频录制 https://github.com/nICEnnnnnnnLee/BilibiliLiveRecorder
- v86 - 浏览器中运行操作系统 https://github.com/copy/v86
- linux-command - Linux命令大全搜索工具 https://github.com/jaywcjlove/linux-command
- gitbook - web部署markdown文档 https://github.com/GitbookIO/gitbook
- PicGo - markdown图片上传工具 https://github.com/Molunerfinn/PicGo
- ContextMenuManager - Windows右键菜单管理程序 https://github.com/BluePointLilac/ContextMenuManager
- PowerToys - 微软官方windows实用程序 https://github.com/microsoft/PowerToys
- 
