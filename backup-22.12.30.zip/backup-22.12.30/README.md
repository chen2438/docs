---
description: 当前站点 opennet.top, 主站 chenhaotian.top
---

# 起始页

* **若出现页面加载的情况, 请再次刷新页面.**
* 本站已部署 Cloudflare CDN, 无助于解决以上问题.
* 为了良好的阅读体验, 请勿在国内访问此站点.
* 联系我: me@opennet.top



![加载图标](README.assets/2022-10-05-082720-20221231122939373.png)

![此时 Reload 即可](README.assets/2022-10-05-082541-20221231122942449.png)
