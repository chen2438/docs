---
description: 发布于 2020.02.27
---

# GOG Galaxy 2.0提示“无法下载所需文件”问题的解决方案：

这是该问题对话框

![在这里插入图片描述](gog-galaxy-2.0-ti-shi-wu-fa-xia-zai-suo-xu-wen-jian-wen-ti-de-jie-jue-fang-an.assets/2022-10-05-053136.png)

遇到问题后，使用魔法无效。

**需要进官网下载独立的安装程序，而非下载器。**

![在这里插入图片描述](gog-galaxy-2.0-ti-shi-wu-fa-xia-zai-suo-xu-wen-jian-wen-ti-de-jie-jue-fang-an.assets/2022-10-05-053137.png)

[**下载链接**](https://support.gog.com/hc/zh-cn/articles/360010216193-GOG-GALAXY-Web-%E5%AE%89%E8%A3%85%E7%A8%8B%E5%BA%8F?product=gog)

下载完成后可以直接安装

![在这里插入图片描述](gog-galaxy-2.0-ti-shi-wu-fa-xia-zai-suo-xu-wen-jian-wen-ti-de-jie-jue-fang-an.assets/2022-10-05-053135.png)

安装完成。

![1.2版本](gog-galaxy-2.0-ti-shi-wu-fa-xia-zai-suo-xu-wen-jian-wen-ti-de-jie-jue-fang-an.assets/2022-10-05-053138.png)

注意，若提示更新，必须让它立即更新而不能“稍后更新”，更新完成后在应用内更新到2.0版即可

![2.0版本](gog-galaxy-2.0-ti-shi-wu-fa-xia-zai-suo-xu-wen-jian-wen-ti-de-jie-jue-fang-an.assets/2022-10-05-53139.png)
