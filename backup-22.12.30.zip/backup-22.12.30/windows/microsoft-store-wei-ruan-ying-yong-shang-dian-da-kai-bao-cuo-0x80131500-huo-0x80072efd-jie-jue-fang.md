---
description: 转载于 2022.09.02, 著作权归原作者所有
---

# Microsoft Store微软应用商店打开报错“0x80131500”或“0x80072EFD”解决方案



转自: https://iknow.lenovo.com.cn/detail/kd\_26552.html

在 CSDN 上[查看](https://blog.csdn.net/qq\_34010538/article/details/126659774?spm=1001.2014.3001.5501)

#### 故障现象:

1、Microsoft Store微软应用商店打开报错“0x80131500”或“0x80072EFD”，如图：

![在这里插入图片描述](https://img-blog.csdnimg.cn/177ab6e8701f435e8d44116b3b0e0c22.png)

#### 解决方案:

1、打开控制面板→右上角查看方式选择“大图标”→“Internet 选项”打开，如图：

![在这里插入图片描述](https://img-blog.csdnimg.cn/a08c2103a4c64c0c8ac53029dc07f498.png)

2、打开“连接”→“局域网设置”→去掉代理服务器勾选项→点击确定，如图：

![在这里插入图片描述](https://img-blog.csdnimg.cn/386ca3eb3b674000aa9091eb761ed6ee.png)

3、若上述方案无效，点击“高级”→ 把使用TLS选项都勾上或者选择“还原高级设置”后点击应用，即可修复。

![在这里插入图片描述](https://img-blog.csdnimg.cn/f6200cb38c9b4f80b3b8b44d517c8ab6.png)
