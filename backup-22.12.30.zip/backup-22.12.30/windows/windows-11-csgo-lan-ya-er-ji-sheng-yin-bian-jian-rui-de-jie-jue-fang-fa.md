---
description: 发布于 2021.07.22
---

# Windows 11 CSGO 蓝牙耳机声音变尖锐的解决方法

#### 问题描述

升级Windows 11系统后，CSGO连接蓝牙耳机，声音变尖锐，伴有间歇性停顿。像音频被“加速”一样

#### 解决方法

Win11设置 - Windows更新 - 高级选项 - 可选更新 - 驱动程序更新 - 更新Realtek有关驱动

![在这里插入图片描述](http://nme-200t.oss-cn-hangzhou.aliyuncs.com/notes/2022-10-05-052118.png)

\
