---
description: 发布于 2019.04.13
---

# Excel “剪贴板出现问题，但你仍可在此工作簿内粘贴内容”的解决方案

#### 原因分析

电脑的其他软件占用了剪贴板。

**解决方案**

关闭 PanDownload、迅雷、比特彗星等监控剪切板的软件。

尤其注意**下载器软件**，它会监控**复制链接行为**

![在这里插入图片描述](excel-jian-tie-ban-chu-xian-wen-ti-dan-ni-reng-ke-zai-ci-gong-zuo-bu-nei-nian-tie-nei-rong-de-jie-ju.assets/2022-10-05-053550.png)

\
