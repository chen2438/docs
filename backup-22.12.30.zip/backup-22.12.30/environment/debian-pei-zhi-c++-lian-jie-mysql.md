---
description: 转载于 2022.11.25
---

# debian 配置 C++ 连接 MySQL

参考 [https://blog.csdn.net/fengxinlinux/article/details/75675360](https://blog.csdn.net/fengxinlinux/article/details/75675360)

```bash
apt install libmysqld-dev
apt install libmysqlclient-dev
```
