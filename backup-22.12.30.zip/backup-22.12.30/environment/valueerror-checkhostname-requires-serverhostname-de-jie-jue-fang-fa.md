---
description: 发布于 2021.07.22
---

# ValueError: check\_hostname requires server\_hostname的解决方法

#### 问题描述：

![在这里插入图片描述](valueerror-checkhostname-requires-serverhostname-de-jie-jue-fang-fa.assets/2022-10-05-51047.png)

在安装`pygame`库时遇到报错，结尾是`ValueError: check_hostname requires server_hostname`

#### 解决方法：

关闭 VPN / 代理

![在这里插入图片描述](valueerror-checkhostname-requires-serverhostname-de-jie-jue-fang-fa.assets/2022-10-05-051046.png)

\
