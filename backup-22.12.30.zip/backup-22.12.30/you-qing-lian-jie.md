# 友情链接

### 文档 & 教程

**Linux Command** - Linux 命令速查手册 [Github](https://github.com/jaywcjlove/linux-command) | [WEB](https://qq.wdev.cn/)

**Docker — 从入门到实践** [Github](https://github.com/yeasy/docker\_practice) | [WEB](https://yeasy.gitbook.io/docker\_practice/)

**MDN 中文** [WEB](https://developer.mozilla.org/zh-CN/docs/Web)

**Node.js 中文教程** [WEB](http://dev.nodejs.cn/learn)

**Nginx 中文教程** [WEB](https://www.cainiaojc.com/nginx/nginx-index.html)

### 工具

**站长工具** [WEB](https://tool.chinaz.com/)

**ping.pe** [WEB](https://ping.pe/)

**Icon Maker -** 在线图标制作工具 [WEB](https://icon.ray.so/)

### 云服务器

#### 国内

阿里云 [官网](https://www.aliyun.com/) | [控制台](https://home.console.aliyun.com/)

腾讯云 [官网](https://cloud.tencent.com/) | [控制台](https://console.cloud.tencent.com/)

华为云 [官网](https://www.huaweicloud.com/) | [控制台](https://console.huaweicloud.com/)

亿速云 [官网](https://www.yisu.com/) | [控制台](https://www.yisu.com/)

ucloud [官网](https://www.ucloud.cn/) | [控制台](https://www.ucloud.cn/)

硅云 [官网](https://www.vpsor.cn/)

#### 国外

甲骨文 [官网](https://www.oracle.com/cn/)

Azure [官网](https://azure.microsoft.com/zh-cn/) | [控制台](https://portal.azure.com/)

Google Cloud
