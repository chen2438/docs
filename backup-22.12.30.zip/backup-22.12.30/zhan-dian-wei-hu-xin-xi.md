# 站点维护信息

### Todo List

* 完善随机图 API 和图库

### Done

#### 22.10.4

* 挂载 GitBook 作为文档服务器

#### 22.9.27

- 重置站点
- 使用 Git 进行版本控制

#### 22.9.10

* 部署自己的随机图 API, 支持跨域访问

#### 22.9.9

* 部署 SSL, 支持 HTTPS

### Server Information

Ubuntu 20.04.5 LTS

Docker version 20.10.17, build 100c701

8.0.30 MySQL Community Server - GPL

Apache/2.4.54 (Debian)

WordPress: 6.0.2
